# Bibliotecas de trabalho

## Importação das NFs

#Importações de bibliotecas
#--------------------------
# Para carregar variáveis de ambiente
from dotenv import load_dotenv
load_dotenv()  # carrega variáveis do arquivo .env
# Para tratar o arquivo ZIP.
import os
# Para ler os arquivos e salvar em banco de dados
import csv
import pandas as pd
# app.py (na raiz de C:\AgenteIA\AgenteNF\)

from core.ingestion import read_csv_safely  # <- nosso módulo do Passo 1
from core.memory import (
    InsightsStore,
    register_basic_stats,
    register_frequency,
    register_distribution,
    register_outliers,
    register_correlation,
    summarize_insights,
)

# import psycopg2
# from psycopg2 import Error

# Acesso a área Secrets
# from google.colab import userdata

# Acesso ao LLM


from langchain_openai import ChatOpenAI

from langchain.globals import set_llm_cache
from langchain_community.cache import InMemoryCache

# ativa o cache para melhorar a performance
set_llm_cache(InMemoryCache())


# Para criar a interface web
import streamlit as st
from langchain_openai import OpenAI


# --- sessão global ---
if "insights_store" not in st.session_state:
    from core.memory import InsightsStore
    st.session_state["insights_store"] = InsightsStore()

# Definição do repositório e arquivo.

# TODO: Alterar a origem de dados quando em produção.


st.set_page_config(page_title="Agente EDA - Carregar CSV", layout="wide")
with st.sidebar:
    st.header("Configurações de Leitura do CSV")
    opt_encoding = st.selectbox("Encoding", ["auto","utf-8","utf-8-sig","latin-1","cp1252"], index=0)
    opt_delim    = st.selectbox("Delimitador", ["auto",";", ",", "\\t", "|"], index=0)
    opt_decimal  = st.selectbox("Separador decimal", ["auto",".",","], index=0)
    opt_quote    = st.selectbox("Aspas", ["auto",'"',"'", "sem aspas"], index=0)
    opt_bad      = st.selectbox("Linhas problemáticas", ["padrão","pular (skip)"], index=0)
    opt_sniff    = st.checkbox("Detectar separador automaticamente (Sniffer)", value=False)
    opt_sample   = st.number_input("Amostrar se > N linhas (opcional)", min_value=0, value=0, step=10000)
st.title("1) Carregar dados (CSV)")

uploaded = st.file_uploader("Envie um arquivo CSV", type=["csv"])

# Monta hints com base nas escolhas do usuário
user_hints = {}
if opt_encoding != "auto":
    user_hints["encoding"] = opt_encoding
if opt_delim != "auto":
    user_hints["delimiter"] = "\t" if opt_delim.strip() == "\\t" else opt_delim.strip()
if opt_decimal != "auto":
    user_hints["decimal"] = opt_decimal

if opt_quote == "sem aspas":
    user_hints["quoting"] = __import__("csv").QUOTE_NONE
    user_hints["quotechar"] = None
    user_hints["escapechar"] = "\\"
elif opt_quote != "auto":
    user_hints["quotechar"] = opt_quote

if opt_bad == "pular (skip)":
    user_hints["on_bad_lines"] = "skip"

if opt_sniff:
    user_hints["sniff_sep"] = True


if uploaded is not None:
    file_bytes = uploaded.read()
    file_name = uploaded.name
    sample_rows_if_huge = opt_sample if opt_sample and opt_sample > 0 else None

    try:
        df, meta, profile = read_csv_safely(
            file_bytes=file_bytes,
            file_name=file_name,
            user_hints=user_hints if user_hints else None,
            convert_dtypes=True,
            sample_rows_if_huge=sample_rows_if_huge
        )

        # Guarda tudo na sessão
        st.session_state["df"] = df
        st.session_state["profile"] = profile
        st.session_state["dataset_meta"] = meta.__dict__
        st.session_state["dataset_id"] = meta.dataset_id

        # Inicializa ou limpa a memória de insights para o dataset atual
        if "insights_store" not in st.session_state:
            st.session_state["insights_store"] = InsightsStore()

        # garante que o dataset existe no store, mas sem limpar eventos antigos
        st.session_state["insights_store"].ensure_dataset(meta.dataset_id, meta.__dict__)
    
        st.success(f"CSV carregado com sucesso: **{file_name}**")
        st.caption(f"Dataset ID: `{meta.dataset_id}`")

        with st.expander("Metadados de leitura"):
            st.json({
                "encoding": meta.encoding,
                "delimiter": meta.delimiter.replace("\t", "\\t"),
                "decimal": meta.decimal,
                "quotechar": meta.quotechar,
                "n_rows": meta.n_rows,
                "n_cols": meta.n_cols,
                "warnings": meta.warnings,
            })

        st.subheader("Prévia (5 linhas)")
        st.dataframe(df.head(5), use_container_width=True)

        st.subheader("Perfil do Dataset")
        c1, c2, c3 = st.columns([1,1,1])
        with c1:
            st.metric("Linhas", value=profile["shape"][0])
            st.metric("Colunas", value=profile["shape"][1])
            st.metric("Memória (MB)", value=profile["memory_mb"])
        with c2:
            st.markdown("**Tipos (dtypes)**")
            st.json(profile["dtypes"])
        with c3:
            st.markdown("**% de Nulos por coluna**")
            st.json(profile["null_pct"])

        st.markdown("**Cardinalidade (nunique)**")
        st.json(profile["nunique"])

        st.markdown("**Classificação de colunas**")
        st.json(profile["classes"])

        st.info("Dados prontos! Na próxima etapa a gente liga o agente e as ferramentas de EDA (Passos 3 a 7).")

    except Exception as e:
        st.error(f"Falha ao ler o CSV. Detalhes: {e}")
        st.stop()
else:
    st.warning("Envie um arquivo CSV para começar.")

def get_llm_or_none():
    api_key  = os.environ.get('LLM_API_KEY')
    model    = os.environ.get('LLM_MODEL_NAME')
    base_url = os.environ.get('LLM_BASE_URL')
    if not (api_key and model and base_url):
        return None  # só criaremos o LLM quando formos usar na aba "Análises"
    llm_config = {
        'api_key': api_key,
        'model': model,
        'base_url': base_url,
        'temperature': 0,
        'verbose': True,
        'cache': True,
    }
    return ChatOpenAI(**llm_config)

# --- abaixo do perfil ---
st.markdown("---")
st.header("2) Análises")

if "df" not in st.session_state:
    st.info("Carregue um CSV na seção acima para habilitar as análises.")
else:
    from core import eda
    from core import plots

    df = st.session_state["df"]
    profile = st.session_state["profile"]
    classes = profile["classes"]
    num_cols = classes.get("numericas", [])
    all_cols = list(df.columns)

    store = st.session_state.get("insights_store")
    dsid = st.session_state.get("dataset_id")

    # -------- Automação (Varredura rápida) --------
    store = st.session_state["insights_store"]
    dsid = st.session_state["dataset_id"]
    
    st.subheader("Automação")
    if st.button("Varredura automática (EDA rápido)", type="primary", key=f"auto_scan_{dsid}"):
        # ... (seu código que registra stats, frequências, outliers, correlações)
        st.success("Varredura concluída. Veja a aba **Conclusões**.")
        st.rerun()  # <<< força re-render para que o resumo já venha preenchido
        
        # 1) estatísticas
        try:
            stats = eda.basic_stats(df)
            register_basic_stats(store, dsid, df, stats)
        except Exception:
            pass

        # 2) frequências (até 3 colunas categóricas/texto)
        cat_cols = classes.get("categoricas", []) + classes.get("texto", [])
        for c in cat_cols[:3]:
            try:
                counts = eda.frequencies(df, c, top_n=10)
                register_frequency(store, dsid, c, counts)
            except Exception:
                continue

        # 3) distribuição + outliers (até 3 numéricas)
        for c in num_cols[:3]:
            try:
                register_distribution(store, dsid, c)
                out = eda.detect_outliers_iqr(df[c])
                register_outliers(store, dsid, c, out)
            except Exception:
                continue

        # 4) top correlações
        try:
            # requer a função top_correlations no core/eda.py (já enviei)
            top_pairs = eda.top_correlations(df, k=5)
            if top_pairs:
                register_correlation(store, dsid, top_pairs)
        except Exception:
            pass

        st.success("Varredura concluída. Veja a aba **Conclusões**.")

    # -------- Abas de análise --------
    tab1, tab2, tab3, tab4, tab5 = st.tabs(
        ["Estatísticas", "Distribuição/Outliers", "Correlação", "Dispersão", "Conclusões"]
    )

    # === TAB 1: Estatísticas ===
    with tab1:
        st.subheader("Estatísticas básicas")
        try:
            stats = eda.basic_stats(df)
            if "describe" in stats:
                st.dataframe(stats["describe"], use_container_width=True)
            if "variance" in stats and stats["variance"]:
                st.json({"variance": stats["variance"]})

            if store and dsid and st.button("Salvar este achado (estatísticas)", key=f"save_stats_{dsid}"):
                register_basic_stats(store, dsid, df, stats)
                st.success("Estatísticas registradas na memória.")
        except Exception as e:
            st.warning(f"Não foi possível calcular estatísticas: {e}")

        st.subheader("Frequências (coluna categórica ou texto)")
        col = st.selectbox("Coluna", options=all_cols, key=f"freq_col_{dsid}")
        topn = st.slider("Top N", 5, 50, 20, key=f"freq_topn_{dsid}")
        try:
            counts = eda.frequencies(df, col, topn)
            st.dataframe(counts)
            if store and dsid and st.button("Salvar este achado (frequências)", key=f"save_freq_{dsid}"):
                register_frequency(store, dsid, col, counts)
                st.success("Frequência registrada na memória.")
        except Exception as e:
            st.warning(f"Falha nas frequências: {e}")

    # === TAB 2: Distribuição/Outliers ===
    with tab2:
        st.subheader("Distribuição (numérica)")
        if not num_cols:
            st.info("Não há colunas numéricas detectadas.")
        else:
            colnum = st.selectbox("Coluna numérica", options=num_cols, key=f"dist_col_{dsid}")
            series = df[colnum]
            fig_h = plots.plot_hist(series.rename(colnum))
            st.pyplot(fig_h, use_container_width=True)

            if store and dsid and st.button("Salvar este achado (distribuição)", key=f"save_dist_{dsid}"):
                register_distribution(store, dsid, colnum)
                st.success("Distribuição registrada.")

            st.subheader("Outliers (IQR)")
            try:
                out = eda.detect_outliers_iqr(series)
                st.json(out)
                fig_b = plots.plot_box(series.rename(colnum))
                st.pyplot(fig_b, use_container_width=True)

                if store and dsid and st.button("Salvar este achado (outliers)", key=f"save_out_{dsid}"):
                    register_outliers(store, dsid, colnum, out)
                    st.success("Outliers registrados.")
            except Exception as e:
                st.warning(f"Falha na detecção de outliers: {e}")

    # === TAB 3: Correlação ===
    with tab3:
        st.subheader("Matriz de correlação")
        try:
            corr = eda.correlation_matrix(df)
            fig_c = plots.plot_corr_heatmap(corr)
            st.pyplot(fig_c, use_container_width=True)

            # top pares para memória
            try:
                top_pairs = eda.top_correlations(df, k=5)
            except Exception:
                top_pairs = []

            if store and dsid and top_pairs and st.button("Salvar este achado (top correlações)", key=f"save_corr_{dsid}"):
                register_correlation(store, dsid, top_pairs)
                st.success("Correlação registrada.")
        except Exception as e:
            st.warning(f"Falha na correlação: {e}")

    # === TAB 4: Dispersão ===
    with tab4:
        st.subheader("Gráfico de dispersão")
        if len(num_cols) < 2:
            st.info("Selecione um dataset com pelo menos 2 colunas numéricas.")
        else:
            c1, c2 = st.columns(2)
            with c1:
                xcol = st.selectbox("X", options=num_cols, key=f"sc_x_{dsid}")
            with c2:
                ycol = st.selectbox("Y", options=[c for c in num_cols if c != xcol], key=f"sc_y_{dsid}")
            try:
                x, y = eda.scatter_data(df, xcol, ycol)
                fig_s = plots.plot_scatter(x, y, xcol, ycol)
                st.pyplot(fig_s, use_container_width=True)
            except Exception as e:
                st.warning(f"Falha no scatter: {e}")

    # === TAB 5: Conclusões ===
    with tab5:
        st.subheader("Conclusões do agente (memória)")

        store = st.session_state.get("insights_store")
        dsid = st.session_state.get("dataset_id")

        if not (store and dsid):
            st.info("Carregue um dataset e salve alguns achados.")
        else:
            # sempre recalcule a cada render
            txt = summarize_insights(store, dsid)
            st.text_area("Resumo gerado", value=txt, height=220, key=f"insights_text_{dsid}")

            # mostra contagem (debug útil)
            try:
                ev_count = len(store.list_events(dsid))
                st.caption(f"Eventos registrados para este dataset: {ev_count}")
            except Exception:
                ev_count = 0

            # LLM opcional
            llm = None
            try:
                llm = get_llm_or_none()
            except Exception:
                llm = None

            has_content = bool(txt.strip()) and "Nenhum insight" not in txt

            if llm:
                disabled = not has_content or ev_count == 0
                if st.button("Melhorar texto com LLM", key=f"llm_rewrite_{dsid}", disabled=disabled):
                    # recalcule imediatamente antes de enviar ao LLM
                    fresh_txt = summarize_insights(store, dsid)
                    if not fresh_txt.strip() or "Nenhum insight" in fresh_txt:
                        st.warning("Ainda não há insights registrados. Execute a Varredura ou salve achados.")
                    else:
                        prompt = (
                            "Reescreva de forma clara e executiva, em bullet points, "
                            "este resumo de conclusões de EDA:\n\n" + fresh_txt
                        )
                        try:
                            resp = llm.invoke(prompt)
                            new_text = getattr(resp, "content", None) or (resp if isinstance(resp, str) else "")
                            if new_text:
                                st.text_area("Versão (LLM)", value=new_text, height=260, key=f"insights_text_llm_{dsid}")
                        except Exception as e:
                            st.warning(f"Falha ao chamar o LLM: {e}")
            else:
                st.caption("Dica: configure LLM_API_KEY, LLM_MODEL_NAME e LLM_BASE_URL no .env para habilitar a reescrita opcional.")
















