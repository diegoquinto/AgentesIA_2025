# core/ingestion.py
from __future__ import annotations

import io
import csv
import re
import hashlib
from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple, List

import numpy as np
import pandas as pd


# ---------- Dataclasses de resultado/erros ----------

@dataclass
class CsvSniffResult:
    encoding: str
    delimiter: str
    decimal: str
    quotechar: str

@dataclass
class IngestionMeta:
    dataset_id: str
    file_name: Optional[str]
    encoding: str
    delimiter: str
    decimal: str
    quotechar: str
    n_rows: int
    n_cols: int
    warnings: List[str]


# ---------- Utilidades internas ----------

_POSSIBLE_ENCODINGS = ["utf-8", "utf-8-sig", "latin-1", "cp1252"]

def _try_detect_encoding(sample: bytes) -> str:
    """Detecta encoding. Usa chardet se disponível; senão, fallbacks."""
    try:
        import chardet  # type: ignore
        guess = chardet.detect(sample or b"")
        enc = (guess.get("encoding") or "").lower()
        if enc:
            return enc
    except Exception:
        pass
    for enc in _POSSIBLE_ENCODINGS:
        try:
            sample.decode(enc)
            return enc
        except Exception:
            continue
    return "utf-8"

def _guess_delimiter(text: str) -> str:
    """Heurística simples para delimitador."""
    candidates = [";", ",", "\t", "|"]
    counts = {c: text.count(c) for c in candidates}
    likely = max(counts, key=counts.get)
    if counts.get(";") and counts.get(","):
        if re.search(r"\d+,\d+", text) and counts[";"] >= counts[","]:
            return ";"
    return likely

def _guess_decimal(text: str, delimiter: str) -> str:
    """Heurística para separador decimal."""
    comma_decimals = len(re.findall(r"\d+,\d+", text))
    dot_decimals = len(re.findall(r"\d+\.\d+", text))
    if comma_decimals > dot_decimals and delimiter in {";", "\t", "|"}:
        return ","
    return "."

def _guess_quotechar(text: str) -> str:
    single = text.count("'")
    double = text.count('"')
    return "'" if single > double else '"'

def _normalize_columns(cols: List[str]) -> List[str]:
    """Normaliza nomes para snake_case sem acentos."""
    import unicodedata
    out = []
    for c in cols:
        c = c.strip()
        c = unicodedata.normalize("NFKD", c).encode("ascii", "ignore").decode("ascii")
        c = re.sub(r"[^\w\s]", "_", c)
        c = re.sub(r"\s+", "_", c)
        c = re.sub(r"_+", "_", c).strip("_").lower()
        out.append(c or "coluna_sem_nome")
    return out

def _hash_dataset(df: pd.DataFrame, meta: Dict[str, Any]) -> str:
    """Cria ID estável do dataset com base em amostra + metadados de leitura."""
    h = hashlib.sha256()
    h.update(str(meta).encode("utf-8"))
    sample = df.head(50).to_csv(index=False).encode("utf-8", errors="ignore")
    h.update(sample)
    return h.hexdigest()[:16]

def _classify_columns(df: pd.DataFrame) -> Dict[str, List[str]]:
    """Classifica colunas por tipo lógico."""
    numericas = df.select_dtypes(include=[np.number]).columns.tolist()

    # pandas compat: use "datetimetz" em vez de "datetime64[ns, tz]"
    try:
        datetimes = df.select_dtypes(include=["datetime64[ns]", "datetimetz"]).columns.tolist()
    except Exception:
        # fallback amplo para versões antigas
        datetimes = df.select_dtypes(include=["datetime64[ns]", "datetime64[ns, UTC]", "datetime64[ns]"]).columns.tolist()

    bools = df.select_dtypes(include=["bool"]).columns.tolist()

    categ, text = [], []
    for col in df.select_dtypes(include=["object", "string"]).columns:
        uniq = df[col].nunique(dropna=True)
        if uniq <= max(50, int(0.05 * len(df))):
            categ.append(col)
        else:
            text.append(col)

    return {
        "numericas": numericas,
        "datetimes": datetimes,
        "bools": bools,
        "categoricas": categ,
        "texto": text,
    }


def _coerce_dtypes(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
    """Converte datas, números com vírgula e bools textuais; retorna avisos."""
    warnings: List[str] = []

    # datas por nome
    date_like = [c for c in df.columns if re.search(r"(data|date|timestamp|time)", c, flags=re.I)]
    for c in date_like:
        try:
            df[c] = pd.to_datetime(df[c], errors="ignore", dayfirst=True, infer_datetime_format=True)
        except Exception:
            warnings.append(f"Falha ao converter coluna '{c}' para datetime.")

    # strings numéricas com vírgula
    for c in df.select_dtypes(include=["object", "string"]).columns:
        s = df[c].astype(str)
        if s.str.contains(r"\d+[.,]\d+", regex=True, na=False).mean() > 0.6:
            try:
                df[c] = (
                    s.str.replace(".", "", regex=False)
                     .str.replace(",", ".", regex=False)
                     .astype(float)
                )
            except Exception:
                pass

    # bools textuais
    truthy = {"true","t","1","y","yes","sim"}
    falsy  = {"false","f","0","n","no","nao","não"}
    for c in df.select_dtypes(include=["object", "string"]).columns:
        s = df[c].astype(str).str.strip().str.lower()
        if s.isin(truthy | falsy).mean() > 0.8:
            df[c] = s.isin(truthy)

    return df, warnings


# ---------- API pública ----------

def sniff_csv_params(raw_file: bytes) -> CsvSniffResult:
    """Infere encoding, delimitador, decimal e quotechar a partir de amostra."""
    sample = raw_file[:200_000]
    encoding = _try_detect_encoding(sample)
    try:
        text = sample.decode(encoding, errors="ignore")
    except Exception:
        text = sample.decode("utf-8", errors="ignore")
    delimiter = _guess_delimiter(text)
    decimal   = _guess_decimal(text, delimiter)
    quotechar = _guess_quotechar(text)
    return CsvSniffResult(encoding=encoding, delimiter=delimiter, decimal=decimal, quotechar=quotechar)


def generate_profile(df: pd.DataFrame) -> Dict[str, Any]:
    """Perfil sintético do dataset."""
    dtypes = df.dtypes.astype(str).to_dict()
    null_pct = (df.isna().mean() * 100).round(2).to_dict()
    nunique = {c: int(df[c].nunique(dropna=True)) for c in df.columns}
    mem_mb = float(df.memory_usage(index=True, deep=True).sum() / 1024**2)
    classes = _classify_columns(df)

    stats = {}
    num_cols = classes["numericas"]
    if num_cols:
        desc = df[num_cols].describe().to_dict()
        stats["numericas_describe"] = desc

    return {
        "shape": df.shape,
        "dtypes": dtypes,
        "null_pct": null_pct,
        "nunique": nunique,
        "memory_mb": round(mem_mb, 2),
        "classes": classes,
    }


def read_csv_safely(
    file_bytes: bytes,
    file_name: Optional[str] = None,
    user_hints: Optional[Dict[str, Any]] = None,
    convert_dtypes: bool = True,
    sample_rows_if_huge: Optional[int] = None,
) -> Tuple[pd.DataFrame, IngestionMeta, Dict[str, Any]]:
    """
    Lê um CSV de forma robusta. Aceita dicas do usuário para sobrescrever sniff (delimiter/decimal/encoding/quotechar)
    e também alguns parâmetros avançados (on_bad_lines, header, quoting, escapechar, sniff_sep).
    Retorna (df, meta, profile).
    """
    warnings: List[str] = []
    hints = user_hints or {}

    sniff = sniff_csv_params(file_bytes)
    encoding  = hints.get("encoding", sniff.encoding)
    delimiter = hints.get("delimiter", sniff.delimiter)
    decimal   = hints.get("decimal", sniff.decimal)
    quotechar = hints.get("quotechar", sniff.quotechar)

    # parâmetros avançados opcionais
    on_bad_lines = hints.get("on_bad_lines", None)   # "skip" | "warn" | None
    header_opt   = hints.get("header", "infer")      # 0 | "infer" | None
    sniff_sep    = bool(hints.get("sniff_sep", False))
    quoting_opt  = hints.get("quoting", None)        # csv.QUOTE_NONE | None
    escapechar   = hints.get("escapechar", None)     # ex.: "\\"

    # kwargs base
    read_kwargs = dict(
        sep=delimiter,
        decimal=decimal,
        encoding=encoding,
        engine="python",
        header=0 if header_opt == 0 else "infer",
        quotechar=quotechar,
    )
    if on_bad_lines:
        read_kwargs["on_bad_lines"] = on_bad_lines
    if quoting_opt is not None:
        read_kwargs["quoting"] = quoting_opt
        if quoting_opt == csv.QUOTE_NONE and not escapechar:
            read_kwargs["escapechar"] = "\\"
        elif escapechar:
            read_kwargs["escapechar"] = escapechar

    # ------------- Tentativa 1 -------------
    try:
        df = pd.read_csv(io.BytesIO(file_bytes), **read_kwargs)
    except Exception as e1:
        warnings.append(f"Tentativa 1 falhou ({read_kwargs}). Erro: {e1}")

        # ------------- Tentativa 2: troca decimal -------------
        try_kwargs = read_kwargs.copy()
        try_kwargs["decimal"] = "." if decimal == "," else ","
        try:
            df = pd.read_csv(io.BytesIO(file_bytes), **try_kwargs)
            warnings.append("Leitura OK na Tentativa 2 (trocando decimal).")
        except Exception as e2:
            warnings.append(f"Tentativa 2 falhou ({try_kwargs}). Erro: {e2}")

            # ------------- Tentativa 3: pular linhas ruins -------------
            try_kwargs = read_kwargs.copy()
            try_kwargs["on_bad_lines"] = "skip"
            try:
                df = pd.read_csv(io.BytesIO(file_bytes), **try_kwargs)
                warnings.append("Leitura OK na Tentativa 3 (on_bad_lines='skip').")
            except Exception as e3:
                warnings.append(f"Tentativa 3 falhou ({try_kwargs}). Erro: {e3}")

                # ------------- Tentativa 4: ignorar aspas -------------
                try_kwargs = read_kwargs.copy()
                try_kwargs["quoting"] = csv.QUOTE_NONE
                try_kwargs["quotechar"] = None
                try_kwargs["escapechar"] = "\\"
                try_kwargs["on_bad_lines"] = "skip"
                try:
                    df = pd.read_csv(io.BytesIO(file_bytes), **try_kwargs)
                    warnings.append("Leitura OK na Tentativa 4 (QUOTE_NONE + skip).")
                except Exception as e4:
                    warnings.append(f"Tentativa 4 falhou ({try_kwargs}). Erro: {e4}")

                    # ------------- Tentativa 5: sniffer do sep -------------
                    try_kwargs = read_kwargs.copy()
                    try_kwargs.pop("sep", None)
                    try_kwargs["sep"] = None  # ativa sniffer (engine='python')
                    try_kwargs["on_bad_lines"] = "skip"
                    try:
                        df = pd.read_csv(io.BytesIO(file_bytes), **try_kwargs)
                        warnings.append("Leitura OK na Tentativa 5 (sep=None + skip).")
                    except Exception as e5:
                        warnings.append(f"Tentativa 5 falhou ({try_kwargs}). Erro: {e5}")

                        # ------------- Tentativa 6: encodings alternativos -------------
                        for enc in _POSSIBLE_ENCODINGS:
                            try_kwargs = read_kwargs.copy()
                            try_kwargs["encoding"] = enc
                            try_kwargs["on_bad_lines"] = "skip"
                            try:
                                df = pd.read_csv(io.BytesIO(file_bytes), **try_kwargs)
                                warnings.append(f"Leitura OK na Tentativa 6 (encoding={enc} + skip).")
                                break
                            except Exception as e6:
                                warnings.append(f"Tentativa 6 falhou (encoding={enc}). Erro: {e6}")
                        else:
                            raise RuntimeError("Não foi possível ler o CSV com os fallbacks testados.")

    # normaliza nomes e segue
    df.columns = _normalize_columns([str(c) for c in df.columns])

    if sample_rows_if_huge and len(df) > sample_rows_if_huge:
        df = df.sample(n=sample_rows_if_huge, random_state=13)
        warnings.append(f"Dataset grande. Amostrado para {sample_rows_if_huge} linhas para EDA inicial.")

    if convert_dtypes:
        df, w = _coerce_dtypes(df)
        warnings.extend(w)

    profile = generate_profile(df)
    meta = IngestionMeta(
        dataset_id=_hash_dataset(df, {
            "file_name": file_name, "encoding": encoding, "delimiter": delimiter,
            "decimal": decimal, "quotechar": quotechar
        }),
        file_name=file_name,
        encoding=encoding,
        delimiter=delimiter,
        decimal=decimal,
        quotechar=quotechar,
        n_rows=len(df),
        n_cols=df.shape[1],
        warnings=warnings
    )
    return df, meta, profile
