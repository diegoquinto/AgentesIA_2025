# core/eda.py
from __future__ import annotations
from typing import Dict, Any, Tuple, List
import numpy as np
import pandas as pd

def basic_stats(df: pd.DataFrame) -> Dict[str, Any]:
    """Describe de colunas numéricas + variância."""
    num = df.select_dtypes(include="number")
    out: Dict[str, Any] = {}
    if not num.empty:
        desc = num.describe(percentiles=[0.25, 0.5, 0.75]).T
        out["describe"] = desc
        out["variance"] = num.var().to_dict()
    return out

def frequencies(df: pd.DataFrame, col: str, top_n: int = 20) -> pd.Series:
    """Top-N de frequências (inclui NaN)."""
    if col not in df.columns:
        raise ValueError(f"Coluna '{col}' não existe.")
    return df[col].value_counts(dropna=False).head(top_n)

def distribution(df: pd.DataFrame, col: str) -> pd.Series:
    """Série numérica limpa para hist/box."""
    if col not in df.columns:
        raise ValueError(f"Coluna '{col}' não existe.")
    s = df[col]
    if not np.issubdtype(s.dropna().dtype, np.number):
        raise ValueError("Distribuição requer coluna numérica.")
    return s.dropna()

def detect_outliers_iqr(series: pd.Series) -> Dict[str, Any]:
    """Resumo de outliers via IQR."""
    s = series.dropna()
    if s.empty:
        return {"count": 0, "pct": 0.0, "lower": None, "upper": None, "idx": []}
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    mask = (s < lower) | (s > upper)
    idx = s[mask].index.tolist()
    return {
        "count": int(mask.sum()),
        "pct": float(100 * mask.mean()),
        "lower": float(lower),
        "upper": float(upper),
        "idx": idx,
    }

def correlation_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """
    Matriz de correlação apenas de colunas numéricas.
    Lança erro se houver < 2 colunas numéricas.
    """
    num = df.select_dtypes(include="number")
    if num.shape[1] < 2:
        raise ValueError("É preciso pelo menos 2 colunas numéricas para correlação.")
    # como já filtramos numéricas, não precisamos do numeric_only
    return num.corr()

def top_correlations(df: pd.DataFrame, k: int = 5) -> List[Dict[str, Any]]:
    """
    Retorna os k pares mais correlacionados:
    [{"pair": ("colA","colB"), "corr": 0.91}, ...]
    """
    num = df.select_dtypes(include="number")
    if num.shape[1] < 2:
        return []
    corr = num.corr()
    pairs: List[Dict[str, Any]] = []
    cols = corr.columns.tolist()
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            c = corr.iloc[i, j]
            if pd.notna(c):
                pairs.append({"pair": (cols[i], cols[j]), "corr": float(c)})
    pairs.sort(key=lambda x: abs(x["corr"]), reverse=True)
    return pairs[:k]

def scatter_data(df: pd.DataFrame, x: str, y: str) -> Tuple[pd.Series, pd.Series]:
    """Dados limpos para scatter (x,y numéricos)."""
    if x not in df.columns or y not in df.columns:
        raise ValueError("Colunas não encontradas.")
    sx, sy = df[x], df[y]
    if not (np.issubdtype(sx.dropna().dtype, np.number) and np.issubdtype(sy.dropna().dtype, np.number)):
        raise ValueError("Scatter requer colunas numéricas.")
    # alinha os índices após remoção de NaN
    sxy = pd.concat([sx, sy], axis=1).dropna()
    return sxy[x], sxy[y]
