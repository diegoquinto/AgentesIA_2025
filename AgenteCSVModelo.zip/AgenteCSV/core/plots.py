# C:\AgenteIA\AgenteNF\core\plots.py
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

def plot_hist(series: pd.Series):
    fig, ax = plt.subplots()
    ax.hist(series.dropna(), bins=30)
    ax.set_title(f"Histograma — {series.name}")
    ax.set_xlabel(series.name); ax.set_ylabel("Frequência")
    fig.tight_layout()
    return fig

def plot_box(series: pd.Series):
    fig, ax = plt.subplots()
    ax.boxplot(series.dropna(), vert=True)
    ax.set_title(f"Boxplot — {series.name}")
    fig.tight_layout()
    return fig

def plot_corr_heatmap(corr: pd.DataFrame):
    fig, ax = plt.subplots()
    im = ax.imshow(corr.values)
    ax.set_xticks(range(len(corr.columns))); ax.set_xticklabels(corr.columns, rotation=90)
    ax.set_yticks(range(len(corr.columns))); ax.set_yticklabels(corr.columns)
    ax.set_title("Correlação (numéricas)")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    return fig

def plot_scatter(x: pd.Series, y: pd.Series, xlab: str, ylab: str):
    fig, ax = plt.subplots()
    ax.scatter(x, y, s=10, alpha=0.7)
    ax.set_xlabel(xlab); ax.set_ylabel(ylab)
    ax.set_title(f"Dispersão — {xlab} vs {ylab}")
    fig.tight_layout()
    return fig
