# core/memory.py
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, List, Optional
from datetime import datetime

import pandas as pd

# ===== Modelo de dado =====
@dataclass
class InsightEvent:
    """Um achado individual que podemos registrar na memória."""
    kind: str               # ex: 'basic_stats', 'frequency', 'distribution', 'outliers', 'correlation', 'scatter', 'timeseries'
    title: str              # ex: 'Top correlações (3)', 'Outliers em preco'
    payload: Dict[str, Any] # dados do achado (ex: {col: ..., stats: ..., limites: ...})
    note: Optional[str]     # frase curta “humana” sobre o que isso significa
    created_at: str         # ISO string

def now_iso() -> str:
    return datetime.utcnow().isoformat(timespec="seconds") + "Z"

# ===== Store simples em memória (session) =====
class InsightsStore:
    """
    Armazena insights por dataset_id.
    - Estrutura: { dataset_id: { "events": [InsightEvent...], "meta": {...} } }
    """
    def __init__(self):
        self._data: Dict[str, Dict[str, Any]] = {}

    def ensure_dataset(self, dataset_id: str, meta: Optional[Dict[str, Any]] = None):
        if dataset_id not in self._data:
            self._data[dataset_id] = {"events": [], "meta": meta or {}}
        elif meta:
            self._data[dataset_id]["meta"] = meta

    def add_event(self, dataset_id: str, event: InsightEvent):
        self.ensure_dataset(dataset_id)
        self._data[dataset_id]["events"].append(asdict(event))

    def list_events(self, dataset_id: str) -> List[Dict[str, Any]]:
        self.ensure_dataset(dataset_id)
        return self._data[dataset_id]["events"]

    def clear_dataset(self, dataset_id: str):
        self._data[dataset_id] = {"events": [], "meta": {}}

    def export_dataset(self, dataset_id: str) -> Dict[str, Any]:
        self.ensure_dataset(dataset_id)
        return self._data[dataset_id]

# ===== Helpers de alto nível =====
def register_basic_stats(store: InsightsStore, dataset_id: str, df: pd.DataFrame, stats: Dict[str, Any]):
    if "describe" in stats:
        event = InsightEvent(
            kind="basic_stats",
            title="Estatísticas básicas (numéricas)",
            payload={"describe": stats["describe"].to_dict() if hasattr(stats["describe"], "to_dict") else stats["describe"]},
            note="Medidas de tendência central e dispersão calculadas para colunas numéricas.",
            created_at=now_iso(),
        )
        store.add_event(dataset_id, event)

def register_frequency(store: InsightsStore, dataset_id: str, col: str, series_counts):
    event = InsightEvent(
        kind="frequency",
        title=f"Frequências — {col}",
        payload={"column": col, "top": series_counts.to_dict()},
        note=f"Valores mais frequentes na coluna '{col}'.",
        created_at=now_iso(),
    )
    store.add_event(dataset_id, event)

def register_distribution(store: InsightsStore, dataset_id: str, col: str):
    event = InsightEvent(
        kind="distribution",
        title=f"Distribuição — {col}",
        payload={"column": col},
        note=f"Histograma/boxplot avaliados para '{col}'.",
        created_at=now_iso(),
    )
    store.add_event(dataset_id, event)

def register_outliers(store: InsightsStore, dataset_id: str, col: str, out: Dict[str, Any]):
    note = None
    try:
        if isinstance(out, dict) and "pct" in out:
            note = f"Outliers ~{out.get('pct', 0):.2f}% na coluna '{col}'."
    except Exception:
        pass

    event = InsightEvent(
        kind="outliers",
        title=f"Outliers — {col}",
        payload={"column": col, "summary": out or {}},  # <<< garante dict
        note=note,
        created_at=now_iso(),
    )
    store.add_event(dataset_id, event)


def register_correlation(store: InsightsStore, dataset_id: str, top_pairs: List[Dict[str, Any]]):
    # top_pairs: [{"pair": ("colA","colB"), "corr": 0.91}, ...]
    tip = ", ".join([f"{p['pair'][0]}~{p['pair'][1]} ({p['corr']:.2f})" for p in top_pairs[:3]]) if top_pairs else "—"
    event = InsightEvent(
        kind="correlation",
        title="Top correlações",
        payload={"top_pairs": top_pairs},
        note=f"Pares mais correlacionados: {tip}.",
        created_at=now_iso(),
    )
    store.add_event(dataset_id, event)

def summarize_insights(store: InsightsStore, dataset_id: str) -> str:
    """Gera um texto conciso com as principais conclusões baseadas nos events."""
    evs = store.list_events(dataset_id)
    if not evs:
        return "Nenhum insight registrado ainda. Execute a Varredura automática ou salve alguns achados."

    bullets: List[str] = []
    # 1) correlações
    for ev in evs:
        if ev["kind"] == "correlation" and ev["payload"].get("top_pairs"):
            pairs = ev["payload"]["top_pairs"][:3]
            s = "; ".join([f"{a}↔{b} (ρ={c:.2f})" for (a, b), c in [(p["pair"], p["corr"]) for p in pairs]])
            bullets.append(f"Correlação: {s}.")
            break

    # 2) outliers
    out_notes = []
    for ev in evs:
        if ev.get("kind") == "outliers":
            payload = ev.get("payload") or {}
            summ = payload.get("summary") or {}
            if not isinstance(summ, dict):
                summ = {}
            pct = float(summ.get("pct", 0.0)) if "pct" in summ else 0.0
            col = payload.get("column")
            if pct and pct > 0 and col:
                out_notes.append(f"{col}: {pct:.2f}%")

    # 3) frequências
    freq_notes = []
    for ev in evs:
        if ev.get("kind") == "frequency":
            payload = ev.get("payload") or {}
            col = payload.get("column")
            top = payload.get("top") or {}
            if isinstance(top, dict):
                top_items = list(top.items())[:3]
                if top_items and col:
                    freq_notes.append(f"{col}: {', '.join([f'{k} ({v})' for k, v in top_items])}")

    # 4) estatísticas
    for ev in evs:
        if ev["kind"] == "basic_stats":
            bullets.append("Estatísticas descritivas calculadas para variáveis numéricas.")
            break

    if not bullets:
        return "Insighs registrados, mas nada de destaque foi encontrado automaticamente."
    return "Conclusões preliminares:\n- " + "\n- ".join(bullets)
